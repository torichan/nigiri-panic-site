# Co-op sushi cooking game "Nigiri Panic" launches on the App Store — full game 50% off until November 30

〔Release date〕 — Independent developer Yokke

Independent developer Yokke today released Nigiri Panic, a co-op cooking action game set in a busy sushi restaurant, on the App Store for iPhone and iPad. World 1 and the tutorial are free to play, and Worlds 2–6 unlock with a single one-time purchase. To celebrate the launch, the full game is 50% off ($4.99) until November 30, 2026. An Android version is coming soon.

## About the game

Orders are up! Chop the fish, shape the rice, roll the maki, plate it and serve it before the customers give up. The kitchens are split by rivers and gaps, so when your teammate is on the other side, you throw the ingredients across. Who chops, who shapes, who serves? Call it out and keep the kitchen moving.

## Features

- **1–4 players**: play together on one device with controllers, or online with a simple room code (no account needed)
- **A purpose-built solo mode**: swap between two chefs and run the whole kitchen yourself
- **36 stages across 6 worlds**: from festival stalls to icy kitchens, with moving walkways, shifting counters, windy bridges and more
- **A light story**: rescue your kidnapped master, one stage at a time
- **Assist options for everyone**: difficulty, visibility and control settings, all free
- **No ads**. Available in English, Japanese, Korean, Chinese (Simplified & Traditional), Spanish and French

## Pricing

- Free to start (World 1 and the tutorial)
- Full game (Worlds 2–6): $9.99 → **$4.99 until November 30** (launch sale)
- Online Host Pass (only needed to host an online room): $1.99/month or $14.99/year, with a 7-day free trial. Joining a room is free, and if the host owns the full game, friends can play Worlds 2–6 together.

## Assets & contact

- App Store: https://apps.apple.com/us/app/id6797676852
- Website: https://torichan.github.io/nigiri-panic-site/
- Press kit (screenshots, trailer, logos): https://torichan.github.io/nigiri-panic-site/press.html
- Contact: com.yy.app@gmail.com
