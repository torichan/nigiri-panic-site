# Nigiri Panic — fact sheet / 概要

| | |
|---|---|
| Title / タイトル | にぎりパニック / Nigiri Panic |
| Developer / 開発 | Yokke(個人開発 / independent) |
| Platforms / 対応 | iPhone・iPad(iOS 15.0 以降)。Android は近日 / Android coming soon |
| Release / 配信 | 〔公開日 / release date〕 |
| Genre / ジャンル | 協力クッキングアクション / co-op cooking action |
| Players / 人数 | 1–4(ローカル・オンライン協力 / local & online co-op) |
| Content / 内容 | 6 worlds, 36 stages / 6 つの世界・全 36 面 |
| Price / 価格 | 基本無料(世界 1)・本編 ¥980 / $9.99(11/30 まで ¥490 / $4.99)・オンライン ホストパス 月 ¥200 / $1.99・年 ¥1,500 / $14.99(7 日間無料) |
| Ads / 広告 | なし / none |
| Age rating / 年齢区分 | 4+ |
| Languages / 言語 | 日本語・English・한국어・简体中文・繁體中文・Español・Français |
| App Store | https://apps.apple.com/app/id6797676852 |
| Website / 公式サイト | https://torichan.github.io/nigiri-panic-site/ |
